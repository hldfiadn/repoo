function o(e) {
    e = document.cookie.match("(^|;)\\s*" + e + "\\s*=\\s*([^;]+)");
    return e ? e.pop() : ""
}

setBadgeCheckoutCount = function() {
    var e = 0;
    try {
        var t = JSON.parse(o("Carts"));
        console.log(t);
        "" !== t && (e = JSON.parse(decodeURIComponent(t)).cartItems)
    } catch (e) {
        console.log(e)
    }
    t = document.getElementById("test");
    t.innerHTML = "CART " + e;
}

setBadgeCheckoutCount();