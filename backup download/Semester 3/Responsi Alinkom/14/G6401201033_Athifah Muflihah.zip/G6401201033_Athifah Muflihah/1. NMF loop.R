
library(matlib)
V <- matrix(c(1,1,1,2,1,1,3,2,2,3,1,1), nrow = 3)
r = 2
H <- matrix(c(1,0,1,1,1,0,0,1), nrow = r)


n = 1
maxiter = 100 #masukkan jumlah iterasi maks
Norm_G = 0
err = 0.00001 #masukkan maks error
for (i in n:maxiter) {
    if (Norm_G == 0 || Norm_G > err){
    H_inv <- inv(H%*%t(H))
    Wt <- H_inv%*%(H%*%t(V))
    W <- t(Wt)
  
    #cek nilai negatif
    W[W<0] <- 1e-9
  
    #menghitung nilai H
    W_inv <- inv(t(W)%*%W)
    H <- W_inv%*%(t(W)%*%V)
  
    #menghilangkan nilai negatif
    H[H<0] <- 0.00000001
  
    #faktorisasi
    Faktor <- W%*%H
  
    #galat
    Galat <- (V-Faktor)
    Norm_G <- sqrt(sum(Galat^2))
    cat("Iterasi ke",i,":", Norm_G, "\n")
    }
}  